import React, { useState } from 'react'
import 'remixicon/fonts/remixicon.css'
import './Navbar.css'

const Navbar = () => {
  const [clicked, setClicked] = useState(false);

  const handleClick = () => {
    setClicked(!clicked);
  }

  const [isSun, setIsSun] = useState(true);

  const toggleIcon = () => {
    setIsSun(!isSun);
  };

  return (
    <div>
      <nav class="navbar navbar-light bg-light justify-content-between">
        <a class="navbar-brand">Synergy watch</a>
        
        <form class="form-inline">
          
          <div onClick={toggleIcon} className='link-bar icon-sm'>
            {isSun? <p><i class="ri-sun-line"></i></p> : <p><i class="ri-moon-line"></i></p>}
          </div>
          <div class="nav-link"><button class="user-icon" type="button">t</button></div>
          <button class="btn btn-secondary my-2 my-sm-0" type="submit">Logout</button>
         
         
        </form>
      
        <div>
        <div id="mobile" onClick={handleClick}>
            <li id="bar" className={clicked? "fas fa-times" : "fas fa-bars"} ></li>
          </div>
        </div>
      </nav>
    </div>
  )
}
export default Navbar

import React from 'react'
import 'remixicon/fonts/remixicon.css'
import './Sidebar.css'


const Sidebar = () => {
  return (
    <div>
      <section className='sidebar-components sticky-top'>
        <div className='container-fluid pl-4  pt-5 a'>
            <div className='sidebar-content'>
            <p>
            <i class="ri-home-3-fill  pr-3"></i>Home
            </p>
            </div>
            <div className='sidebar-content'>
            <p>
            <i class="ri-fire-fill pr-3"></i>Trending
            </p>
            </div>
            <div className='sidebar-content'>
            <p>
            <i class="ri-discord-fill pr-3"></i>Gamming
            </p>
            </div>
            <div className='sidebar-content'>
            <p>
            <i class="ri-save-fill pr-3"></i>Saved
            </p>
            </div>

        </div>

      </section>
      
    </div>
  )
}

export default Sidebar

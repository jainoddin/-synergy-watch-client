import React, { useEffect, useState } from "react";
import axios from "axios";
import cookie from "js-cookie";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import "./Home.css";

const Home = () => {
  return (
    <div>
      <section className="nav_bar_component">
        <Navbar></Navbar>
      </section>
      <section className="container-fluid p-0">
        <div className="row m-0">
          <div className="col-md-3 p-0 sidebar_container">
            <Sidebar></Sidebar>
          </div>
          <div className="col-md-9 p-0 container">
            <section className="banner_componet d-flex align-items-center justify-content-center">
              <h3>Synergy watch</h3>
            </section>
            <section className="input_group_search container my-4">
              <form
                class="example"
                action="/action_page.php"
                style={{ margin: "auto", maxwidth: "300px" }}
              >
                <input type="text" placeholder="Search.." name="search2" />
                <button type="submit">
                  <i class="fa fa-search"></i>
                </button>
              </form>
            </section>

            <section className="thumbnail_layout">
              <div className="container">
                <div className="row">
                  <div className="col-md-4">
                    <div className="thumbnail_image">
                      <img src="http://i.ytimg.com/vi/Xbizke4zftY/hqdefault.jpg?sqp=-oaymwEbCKgBEF5IVfKriqkDDggBFQAAiEIYAXABwAEG&rs=AOn4CLDcrupR1fg3--aPjIrbtWIYhUt3wg"></img>
                    </div>
                    <div className="thumbnail_title">
                      <h6 className="my-3">habsgbcxzmxzmbnjhgscj</h6>
                    </div>
                    <div className="home_channel_description">
                      <div className="channel_logo">
                        <img src="https://yt3.googleusercontent.com/ytc/AIdro_lS5X9km3AcAwGqnmAK9O5KwIY8uIe6flMlrzj8MA=s176-c-k-c0x00ffffff-no"></img>

                      </div>
                      <div>
                        <p>T-series</p>
                        <p>256 m sub</p>
                        <p>26 dec</p>
                      </div>

                    </div>

                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;

import logo from './logo.svg';
import React from 'react';
import './App.css';
import Login from './client/Login';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './client/Home';
import Register from './client/Register';
import Navbar from './client/components/Navbar';


function App() {
  return (
    <div className="App">
    <BrowserRouter>        
        <Routes>
          <Route path='/Home' element={<Home />}></Route>
          <Route path='/' element={<Login />}></Route>
          <Route path='/Register' element={<Register></Register>}></Route>

        </Routes>      
  </BrowserRouter>
  
  
  

  </div>
  );
}

export default App;
